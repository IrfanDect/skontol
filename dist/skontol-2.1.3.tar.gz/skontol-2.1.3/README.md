# KONTOL-CLI

## Install
`pip install kontol-cli`

## Fungsi
`kontol masukin`
